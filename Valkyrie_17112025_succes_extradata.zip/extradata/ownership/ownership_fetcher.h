#pragma once
#include <string>

namespace OwnershipFetcher {
  bool fetch(const std::string& symbol, const std::string& ownerType);
}
